package com.example.baseballtracker2023

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import java.io.IOException
import com.google.gson.Gson


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        getInfo(findViewById(R.id.TitleView));
    }
//    fun getInfo(view: View){
//
//        val client = OkHttpClient()
//
//        val request: Request = Request.Builder()
//            .url("https://api-baseball.p.rapidapi.com/teams?league=1&season=2020")
//            .get()
//            .addHeader("content-type", "application/octet-stream")
//            .addHeader("X-RapidAPI-Key", "a2415cb7e5msh5fe30481b033db9p1a203ajsnbbcaf7d7a895")
//            .addHeader("X-RapidAPI-Host", "api-baseball.p.rapidapi.com")
//            .build()
//
//        val response = client.newCall(request).execute()
//
//        val call = client.newCall(request)
//        call.enqueue(object : Callback{
//        override fun onFailure(call: Call, e: IOException) {
//            println("Error: $e")
//        }
//
//        override fun onResponse(call: Call, response: Response) {
//            println(response.toString())
//            Log.d("D: ",response.toString())
//
//
//        }
//        })
//
//
//    }
    fun getInfo(view: View){


        val request: Request = Request.Builder()
            .url("https://api-baseball.p.rapidapi.com/games?league=1&team=3&id=1")
            .get()
            .addHeader("X-RapidAPI-Key", "059016c823msh0fd3b21bdfb5497p1811adjsna0adf8fac25b")
            .addHeader("X-RapidAPI-Host", "api-baseball.p.rapidapi.com")
            .build()

    val client = OkHttpClient()

    client.newCall(request).enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            // Handle the error
        }

        override fun onResponse(call: Call, response: Response) {
            val responseBody = response.body()
            val body = responseBody?.string()
            val gameResponse = Gson().fromJson(body, GameResponse::class.java)
            val games = gameResponse.response
            println(games)
            // Do something with the list of games
        }
    })


    }
}
data class GameResponse(
    val response: List<Game>
)
data class Game(
    val game_id: Int,
    val league: League,
    val home: Team,
    val away: Team,
    val date: String,
    val time: String
)

data class League(
    val id: Int,
    val name: String
)

data class Team(
    val id: Int,
    val name: String
)




